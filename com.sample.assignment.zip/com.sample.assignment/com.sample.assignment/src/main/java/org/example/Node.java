package org.example;

public class Node {
    int data;
    Node next;

    // constructor
    Node(int d)
    {
        data = d;
        next = null;
    }
}