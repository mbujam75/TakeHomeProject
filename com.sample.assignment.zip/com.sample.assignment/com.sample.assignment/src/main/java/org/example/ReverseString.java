package org.example;

public class ReverseString {
    public static String reverseParentheses(String s){
        int open = 0;
        int startInd = 0;
        int iLenght = s.length();
        for (int i = 0; i < s.length(); i ++){
            if (s.charAt(i) == '('){
                if (open == 0){
                    startInd = i+1;
                }
                open++;
            }
            if (open == 1 && s.charAt(i) == ')'){
                String start = s.substring(0, startInd-1);
                String parens = s.substring(startInd, i - startInd+1);
                String revParens = "";
                for (int k = parens.length()-1; k >= 0 ; k--){

                    if (parens.charAt(k) == '('){
                        revParens+=')';
                    }
                    else if (parens.charAt(k) == ')'){
                        revParens+='(';
                    }else{
                        revParens+=parens.charAt(k);
                    }
                }
                String end = s.substring(i+1,iLenght);
                return reverseParentheses(start + revParens + end);
            }
            if (s.charAt(i) == ')'){
                open--;
            }
        }
        return s;

    }

    public static void main(String args[]){
        String str = "(abcd)";
        System.out.println(reverseParentheses(str));


    }

}
